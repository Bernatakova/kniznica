<!DOCTYPE html lang="sk">
    <head>
        <meta charset="UTF-8">
        <title>Oravská knižnica Antona Habovštiaka</title>
        <link rel="stylesheet" href="./style/index.css">
    </head>
    <body>
    <?php 
        include("header.php");
    ?>
        <div class="wrapper narrow">
            <table>
                <tr>
                    <td>Prihlasovacie meno:</td>
                    <td> <?php
                        echo $_SESSION['nick'];
                        ?>
                    </td>
                </tr>
                <tr>
                    <td>Rola:</td>
                    <td> <?php
                        echo $_SESSION['rola'];
                        ?>
                    </td>
                </tr>
            </table>

        </div>
</body>
</html>