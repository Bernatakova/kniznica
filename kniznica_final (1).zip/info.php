<!DOCTYPE html lang="sk">
    <head>
        <meta charset="UTF-8">
        <title>Oravská knižnica Antona Habovštiaka </title>
        <link rel="stylesheet" href="./style/index.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.2/js/bootstrap.min.js" integrity="sha512-5BqtYqlWfJemW5+v+TZUs22uigI8tXeVah5S/1Z6qBLVO7gakAOtkOzUtgq6dsIo5c0NJdmGPs0H9I+2OHUHVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    </head>
    <body>
    <?php 
        include("header.php");
    ?>
        <div class="wrapper narrow">
            <h1>Informácie</h1>
            <table class="table">
                <tr>
                    <td>Kraj</td>
                    <td>Žilinský</td>
                </tr>
                <tr>
                    <td>Okres</td>
                    <td>Dolný Kubín</td>
                </tr>
                <tr>
                    <td>Teléfonny kontakt</td>
                    <td>043/5862277</td>
                </tr>
                <tr>
                    <td>Mobil</td>
                    <td>0915 839 714</td>
                </tr>
            </table>
            <h3>Mapa polohy Oravskej knižnice: </h3>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2606.5609575600943!2d19.29393061565239!3d49.208887779323454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4715b1d700000015%3A0x7733ba97f7104635!2sOravsk%C3%A1%20kni%C5%BEnica%20Antona%20Habov%C5%A1tiaka!5e0!3m2!1ssk!2ssk!4v1679337202098!5m2!1ssk!2ssk" 
            width="100%" height="450" style="border:0;" 
            allowfullscreen="" loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
        <footer>
            <div class="narrow">
                <h2>PREZENTÁCIA WEBOVEJ STRÁNKY</h2>
                <p>
                    Táto stránka bola vytvorená na základe získaných znalostí z predmetu Webový dizajn 2. <br>
                    Autorka: Jana Bernaťáková
                </p>
            </div>
        </footer>
    </body>
</html>