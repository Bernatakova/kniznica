
<!DOCTYPE html lang="sk">
    <head>
        <meta charset="UTF-8">
        <title>Oravská knižnica Antona Habovštiaka</title>
        <link rel="stylesheet" href="./style/index.css">
    </head>
    <body>
    <?php 
        include("header.php");
    ?>
        <div class="wrapper narrow">
            <h1>Kontakt</h1>
            <p>Kontaktná adresa:</p>
            <p>Oravská knižnica Antona Habovštiaka<br>S. Nováka 1763/2<br>Dolný Kubín<br>026 80<br></p>
            <p>Napíšte nám :</p>
            
            <form>
                <div>
                    <label>Meno a priezvisko</label>
                    <input id="meno" type="text" required>
                </div>
                <div>
                    <label>Emailová adresa</label>
                    <input id="mail" type="text" required>
                </div>
                <div>
                    <label>Telefónne číslo*</label>
                    <input id="cislo">
                </div>
                <div>
                    <label>Predmet</label>
                    <select id="kat">
                        <option selected disabled>Vyberte:</option>
                        <option value="Zaujímam sa o túto knihu">Zaujímam sa o túto knihu...</option>
                        <option value="Predĺženie výpožičnej doby">Predĺženie výpožičnej doby</option>
                        <option value="Všeobecné informácie">Všeobecné informácie</option>
                        <option value="Iné">Iné</option>
                    </select>
                </div>
                <div>
                    <label>Obsah</label>
                    <textarea id="obsah" required></textarea>
                </div>
                <div>
                    <input class="btn" type="submit" value="Odoslať" onclick="saveFile()">
                </div>
            </form>
        </div>
        <footer>
            <div class="narrow">
                <h2>PREZENTÁCIA WEBOVEJ STRÁNKY</h2>
                <p>
                    Táto stránka bola vytvorená na základe získaných znalostí z predmetu Webový dizajn 2. <br>
                    Autorka: Jana Bernaťáková
                </p>
            </div>
        </footer>
    </body>
</html>

<script>
    let saveFile = () => {
    	
        // Get the data from each element on the form.
    	const meno = document.getElementById('meno');
        const mail = document.getElementById('mail');
        const cislo = document.getElementById('cislo');
        const kat = document.getElementById('kat');
        const obsah = document.getElementById('obsah');
        
        // This variable stores all the data.
        let data = 
            'Meno: ' + meno.value + ' \n ' + 
            'Mail: ' + mail.value + ' \n ' + 
            'Cislo: ' + cislo.value + ' \n ' + 
            'Kat.: ' + kat.value + ' \n ' + 
            'Obsah: ' + obsah.value;
        
        // Convert the text to BLOB.
        const textToBLOB = new Blob([data], { type: 'text/plain' });
        const sFileName = 'dataZForm.txt';	   // The file to save the data.

        // simulujeme stiahnutie suboru kliknutim na odkaz
        let newLink = document.createElement("a");
        newLink.download = sFileName;

        if (window.webkitURL != null) {
            newLink.href = window.webkitURL.createObjectURL(textToBLOB);
        }
        else {
            newLink.href = window.URL.createObjectURL(textToBLOB);
            newLink.style.display = "none";
            document.body.appendChild(newLink);
        }

        // kliknutie
        newLink.click(); 
    }
</script>