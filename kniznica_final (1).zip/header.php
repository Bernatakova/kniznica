<?php
session_start();
?>

<nav>
    <div class="narrow">
        <h1>Oravská knižnica Antona Habovštiaka</h1>
        <div>
            <a href="index.php"><span class="menu-btn">O knižnici</span></a>
            <a href="info.php"><span class="menu-btn">Informácie</span></a>
            <a href="knihy.php"><span class="menu-btn">Knihy</span></a>
            <a href="kontakt.php"><span class="menu-btn">Kontakt</span></a>
            <a href="foto.php"><span class="menu-btn">Fotogaléria</span></a>
            <?php
            if (isset($_SESSION['nick'])) {
                if ($_SESSION['rola'] == "admin") {
                    echo '<a href="admin.php"><span class="menu-btn">' . 'KONZOLA' . '</span></a>';
                }
                // uzivatel je prihlaseny z predch. krokov
                echo '<a href="profile.php"><span class="menu-btn">' . $_SESSION['nick'] . '</span></a>';
                echo '<a href="logout.php"><span class="menu-btn">' . 'Log out' . '</span></a>';

            } else {
                // uzivatel je neprihlaseny
                echo '<a href="login.php"><span class="menu-btn">Login</span></a>';
                echo '<a href="register.php"><span class="menu-btn">Registrácia</span></a>';
            }
            ?>
        </div>
    </div>
</nav>