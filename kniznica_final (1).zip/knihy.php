<!DOCTYPE html lang="sk">
    <head>
        <meta charset="UTF-8">
        <title>Oravská knižnica Antona Habovštiaka </title>
        <link rel="stylesheet" href="./style/index.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.2/js/bootstrap.min.js" integrity="sha512-5BqtYqlWfJemW5+v+TZUs22uigI8tXeVah5S/1Z6qBLVO7gakAOtkOzUtgq6dsIo5c0NJdmGPs0H9I+2OHUHVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    </head>
    <body>
    <?php 
        include("header.php");

        if (isset($_GET['kniha'])){
          $kniha = urldecode($_GET['kniha']);
          $servername = "localhost";
          $username = "root";
          $password = "";

          // Create connection
          $conn = new mysqli($servername, $username, $password);

          // Check connection
          if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
          }

          $retval = mysqli_select_db($conn, 'kniznica');


          $sql = "SELECT * FROM knihy WHERE nazov='" . $kniha . "';";
          $result = $conn->query($sql);
          $row = $result->fetch_assoc();
          $conn->close();

          if ($row == null) {
            echo '<script>alert("zadaná kniha nie je v DB")</script>';
          } else {
            if ($row["vypozicana"]  == 0) {
              $servername = "localhost";
              $username = "root";
              $password = "";

              // Create connection
              $conn = new mysqli($servername, $username, $password);

              // Check connection
              if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
              }

              $retval = mysqli_select_db($conn, 'kniznica');


              $sql = "UPDATE knihy SET vypozicana=1, nick='" . $_SESSION['nick'] . "' WHERE nazov='" . $kniha . "';";
              $result = $conn->query($sql);
              if ($result === TRUE) {
                echo '<script>alert("kniha úspešne vypožičaná")</script>';
              } else {
                echo '<script>alert("chyba: ' . $conn->error . '")</script>';
              }
              $conn->close();
            } else {
              echo '<script>alert("zadaná kniha už je vypožičaná")</script>';
            }

          }
        } elseif(isset($_GET['vratit'])){
          $kniha = urldecode($_GET['vratit']);
          $servername = "localhost";
          $username = "root";
          $password = "";

          // Create connection
          $conn = new mysqli($servername, $username, $password);

          // Check connection
          if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
          }

          $retval = mysqli_select_db($conn, 'kniznica');


          $sql = "SELECT * FROM knihy WHERE nazov='" . $kniha . "';";
          $result = $conn->query($sql);
          $row = $result->fetch_assoc();
          $conn->close();

          if ($row == null) {
            echo '<script>alert("zadaná kniha nie je v DB")</script>';
          } else {
            if ($row["vypozicana"]  == 1) {
              $servername = "localhost";
              $username = "root";
              $password = "";

              // Create connection
              $conn = new mysqli($servername, $username, $password);

              // Check connection
              if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
              }

              $retval = mysqli_select_db($conn, 'kniznica');


              $sql = "UPDATE knihy SET vypozicana=0, nick='" . $_SESSION['nick'] . "' WHERE nazov='" . $kniha . "';";
              $result = $conn->query($sql);
              if ($result === TRUE) {
                echo '<script>alert("kniha úspešne vrátené")</script>';
              } else {
                echo '<script>alert("chyba: ' . $conn->error . '")</script>';
              }
              $conn->close();
            } else {
              echo '<script>alert("zadaná kniha už je vrátená")</script>';
            }

          }
        }
    ?>
        <div class="wrapper narrow">
        <?php
          $servername = "localhost";
          $username = "root";
          $password = "";

          // Create connection
          $conn = new mysqli($servername, $username, $password);

          // Check connection
          if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
          }

          $retval = mysqli_select_db($conn, 'kniznica');

          $sql = "SELECT * FROM knihy";
          $result = $conn->query($sql);



          if ($result != false && $result->num_rows > 0) {
              echo "<table>";
              if (isset($_SESSION['nick'])) {
                echo "<tr><td>Nazov</td> <td>Autor</td> <td>Vypozicana</td><td>Možnosti</td></tr>";
              } else {
                echo "<tr><td>Nazov</td> <td>Autor</td> <td>Vypozicana</td></tr>";
              }
            // output data of each row
            while($row = $result->fetch_assoc()) {
              if (isset($_SESSION['nick'])) {
                if ($row["vypozicana"] == 0) {
                  echo "<tr><td>" . $row["nazov"] . "</td> <td>" . $row["autor"]. "</td> <td> ✖ </td> <td> <a href='knihy.php?kniha=" . urlencode($row["nazov"]) . "'>vypožičať'</a> </td> </form></tr>";
                }
                else {
                  if ($row["nick"] == $_SESSION['nick']) {
                    echo "<tr><td>" . $row["nazov"] . "</td> <td>" . $row["autor"]. "</td> <td> ✓ </td> <td> <a href='knihy.php?vratit=" . urlencode($row["nazov"]) . "'>vrátiť'</a></td></tr>";
                  } else {
                    echo "<tr><td>" . $row["nazov"] . "</td> <td>" . $row["autor"]. "</td> <td> ✓ </td> <td> </td></tr>";
                  }
                }

              } else {
                if ($row["vypozicana"] == 0) {
                  echo "<tr><td>" . $row["nazov"] . "</td> <td>" . $row["autor"]. "</td> <td> ✖ </td></tr>";
                }
                else {
                    echo "<tr><td>" . $row["nazov"] . "</td> <td>" . $row["autor"]. "</td> <td> ✓ </td></tr>";
                }
              }

              
            }
              echo "</table>";
          } else {
            echo "Tabulka je prazdna";
          }
          $conn->close();

          ?>
        </div>
        <footer>
            <div class="narrow">
                <h2>PREZENTÁCIA WEBOVEJ STRÁNKY</h2>
                <p>
                    Táto stránka bola vytvorená na základe získaných znalostí z predmetu Webový dizajn 2. <br>
                    Autorka: Jana Bernaťáková
                </p>
            </div>
        </footer>
    </body>
</html>