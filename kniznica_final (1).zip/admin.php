<!DOCTYPE html lang="sk">
    <head>
        <meta charset="UTF-8">
        <title>Oravská knižnica Antona Habovštiaka </title>
        <link rel="stylesheet" href="./style/index.css">
    </head>
    <body>
    <?php 
        include("header.php");

        if (isset($_GET['odstranit'])){
            $kniha = urldecode($_GET['odstranit']);
            $servername = "localhost";
            $username = "root";
            $password = "";

            // Create connection
            $conn = new mysqli($servername, $username, $password);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $retval = mysqli_select_db($conn, 'kniznica');


            $sql = "DELETE FROM knihy WHERE nazov='" . $kniha . "';";
            $result = $conn->query($sql);
            if ($result === TRUE) {
                echo '<script>alert("Kniha úspešne odstránená")</script>';
            } else {
                echo '<script>alert("chyba: ' . $conn->error . '")</script>';
            }
            $conn->close();
        }

        if (isset($_POST['nazov'])) { 
            $servername = "localhost";
            $username = "root";
            $password = "";

            $nazov = $_POST['nazov'];
            $autor = $_POST['autor'];

            // Create connection
            $conn = new mysqli($servername, $username, $password);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $retval = mysqli_select_db($conn, 'kniznica');


            $sql = "INSERT INTO `knihy`(`nazov`, `autor`, `vypozicana`, `nick`) VALUES ('" . $nazov . "','".  $autor . "','0','');";
            $result = $conn->query($sql);
            if ($result === TRUE) {
                echo '<script>alert("Kniha úspešne pridaná")</script>';
            } else {
                echo '<script>alert("chyba: ' . $conn->error . '")</script>';
            }
            $conn->close();
        }

    ?>
        <div class="wrapper narrow">
            <h1>Admin konzola</h1>
            <h2>Pridať novú knihu</h2>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="login">
                <label>Názov:</label>
                <input type="text" name="nazov" value="<?php echo isset($_POST['nazov']) ? $_POST['nazov'] : '' ?>">

                <label>Autor:</label>
                <input type="text" name="autor" value="<?php echo isset($_POST['autor']) ? $_POST['autor'] : '' ?>"><br>


                <input type="submit" value="Pridať" name="SubmitButton">
            </form>
            <h2>Knihy</h2>
            <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
    
                // Create connection
                $conn = new mysqli($servername, $username, $password);
    
                // Check connection
                if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
                }
    
                $retval = mysqli_select_db($conn, 'kniznica');

    
                $sql = "SELECT * FROM knihy";
                $result = $conn->query($sql);
    
    
    
                if ($result != false && $result->num_rows > 0) {
                    echo "<table>";
                    if ($_SESSION['rola'] == "admin") {
                    echo "<tr><td>Nazov</td> <td>Autor</td> <td>Vypozicana</td><td>Možnosti</td></tr>";
                    } else {
                    echo "K tomuto má prístup len ADMIN!";
                    }
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    if ($_SESSION['rola'] == "admin") {
                    if ($row["vypozicana"] == 0) {
                        echo "<tr><td>" . $row["nazov"] . "</td> <td>" . $row["autor"]. "</td> <td> ✖ </td> <td> <a href='admin.php?odstranit=" . urlencode($row["nazov"]) . "'>odstrániť</a> </td> </form></tr>";
                    }
                    else {
                        if ($row["nick"] == $_SESSION['nick']) {
                        echo "<tr><td>" . $row["nazov"] . "</td> <td>" . $row["autor"]. "</td> <td> ✓ </td> <td> - </td></tr>";
                        } else {
                        echo "<tr><td>" . $row["nazov"] . "</td> <td>" . $row["autor"]. "</td> <td> ✓ </td> <td> </td></tr>";
                        }
                    }
    
                    } 
                    
                }
                    echo "</table>";
                } else {
                echo "Tabulka je prazdna";
                }
                $conn->close();
            ?>
        </div>
    <footer>
        <div class="narrow">
            <h2>PREZENTÁCIA WEBOVEJ STRÁNKY</h2>
            <p>
                Táto stránka bola vytvorená na základe získaných znalostí z predmetu Webový dizajn 2. <br>
                Autorka: Jana Bernaťáková
            </p>
        </div>
    </footer>
</body>
</html>
