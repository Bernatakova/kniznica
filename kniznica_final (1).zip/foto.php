<!DOCTYPE html lang="sk">
    <head>
        <meta charset="UTF-8">
        <title>Oravská knižnica Antona Habovštiaka </title>
        <link rel="stylesheet" href="./style/index.css">
    </head>
    <body>
    <?php 
        include("header.php");
    ?>
        <div class="wrapper narrow">
            <h1>Fotogaléria</h1>
            <div id="grid">
                <div class="column">
                    <p>
                        Knižnica južné krídlo
                    </p>
                    <img class="foto" src="./picture/foto1.jpg">

                    <p>
                        Knižnica - Študovňa, zameraná na čitateľskú činnosť
                    </p>
                    <img class="foto" src="./picture/foto2.jpg">
                </div>

                <div class="column">
                    <p>
                       Knižnica severné krídlo
                    </p>
                    <img class="foto" src="./picture/foto3.jpg">

                    
                
        
    
                </div>
            </div>
        </div>
    <footer>
        <div class="narrow">
            <h2>PREZENTÁCIA WEBOVEJ STRÁNKY</h2>
            <p>
                Táto stránka bola vytvorená na základe získaných znalostí z predmetu Webový dizajn 2. <br>
                Autorka: Jana Bernaťáková
            </p>
        </div>
    </footer>
</body>
</html>
