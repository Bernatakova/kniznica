<!DOCTYPE html lang="sk">
    <head>
        <meta charset="UTF-8">
        <title>Oravská knižnica Antona Habovštiaka</title>
        <link rel="stylesheet" href="./style/index.css">
    </head>
    <body>
    <?php 
        include("header.php");
    ?>
        
        <? if isset($_SESSION['nick']): ?>
        <? else: ?>
            <div class="wrapper narrow">
                <h1>Registrácia</h1>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="login">
                    <label>Nick:</label>
                    <input type="text" name="nick" value="<?php echo isset($_POST['nick']) ? $_POST['nick'] : '' ?>">

                    <label>Heslo:</label>
                    <input type="password" name="pass" value="<?php echo isset($_POST['pass']) ? $_POST['pass'] : '' ?>">

                    <label>Heslo opäť:</label>
                    <input type="password" name="pass2" value="<?php echo isset($_POST['pass2']) ? $_POST['pass2'] : '' ?>"><br>

                    <input type="submit" value="Registrovať" name="SubmitButton">
                    <p>Už máte účet? Prejdite na <a href="login.php">Login</a>.</p>
                </form>
                
            </div>
        <? endif; ?>

        <div class="wrapper narrow">
        <?php
        $message = "";
        if (isset($_POST['nick'])){ //check if form was submitted
            $nick = $_POST['nick']; //get input text
            $pass = $_POST['pass']; //get input text
            $pass2 = $_POST['pass2']; //get input text

            if (strlen($nick) < 1) {
                echo "Zadajte nick!";
                die();
            }

            if ($pass !=  $pass2) {
                echo "Heslá sa líšia!";
                die();
            }

            if (strlen($pass) < 8) {
                echo "Heslo musí mať aspoň 8 znakov!";
                die();
            }

            $servername = "localhost";
            $username = "root";
            $password = "";

            // Create connection
            $conn = new mysqli($servername, $username, $password);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $retval = mysqli_select_db($conn, 'kniznica');


            $sql = "SELECT * FROM pouzivatelia WHERE nick = '" . $nick . "';";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            $conn->close();

            if ($row == null) {
                // Create connection
                $conn = new mysqli($servername, $username, $password);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $retval = mysqli_select_db($conn, 'kniznica');

                $pass = password_hash($pass, PASSWORD_DEFAULT);

                $sql = "INSERT INTO `pouzivatelia`(`nick`, `heslo`, `rola`) VALUES ('" . $nick . "','" . $pass . "','pouzivatel')";
                $result = $conn->query($sql);
                if ($result === TRUE) {
                    echo '<script>alert("Účet úspešne vytvorený")</script>';
                } else {
                    echo '<script>alert("chyba: ' . $conn->error . '")</script>';
                }
                $conn->close();
            }
            else {
                echo "Používateľ s týmto nickom už existuje!";
                die();
            }
        }    
        
        ?>   
        </div>    

        
       
        <footer>
            <div class="narrow">
                <h2>PREZENTÁCIA WEBOVEJ STRÁNKY</h2>
                <p>
                    Táto stránka bola vytvorená na základe získaných znalostí z predmetu Webový dizajn 2. <br>
                    Autorka: Jana Bernaťáková
                </p>
            </div>
        </footer>
    </body>
</html>

<script>
    let saveFile = () => {
    	
        // Get the data from each element on the form.
    	const meno = document.getElementById('meno');
        const mail = document.getElementById('mail');
        const cislo = document.getElementById('cislo');
        const kat = document.getElementById('kat');
        const obsah = document.getElementById('obsah');
        
        // This variable stores all the data.
        let data = 
            'Meno: ' + meno.value + ' \n ' + 
            'Mail: ' + mail.value + ' \n ' + 
            'Cislo: ' + cislo.value + ' \n ' + 
            'Kat.: ' + kat.value + ' \n ' + 
            'Obsah: ' + obsah.value;
        
        // Convert the text to BLOB.
        const textToBLOB = new Blob([data], { type: 'text/plain' });
        const sFileName = 'dataZForm.txt';	   // The file to save the data.

        // simulujeme stiahnutie suboru kliknutim na odkaz
        let newLink = document.createElement("a");
        newLink.download = sFileName;

        if (window.webkitURL != null) {
            newLink.href = window.webkitURL.createObjectURL(textToBLOB);
        }
        else {
            newLink.href = window.URL.createObjectURL(textToBLOB);
            newLink.style.display = "none";
            document.body.appendChild(newLink);
        }

        // kliknutie
        newLink.click(); 
    }
</script>