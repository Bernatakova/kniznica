<!DOCTYPE html lang="sk">
    <head>
        <meta charset="UTF-8">
        <title>Oravská knižnica Antona Habovštiaka </title>
        <link rel="stylesheet" href="./style/index.css">
    </head>
    <body>
    <?php 
        include("header.php");
    ?>
        <div class="wrapper narrow">
            <div class="blok">
                <div>
                    <h2>História knižnice </h2>
                    <p>
                        Základy dnešnej Oravskej knižnice Antona Habovštiaka boli položené v roku 1951, keď sa na základe Vyhlášky Ministerstva informácií a osvety z roku 1950 začali vytvárať okresné ľudové knižnice.

Do roku 1954 bola knižnica umiestnená v budove Čaplovičovej knižnice. V súvislosti s prácami na Hviezdoslavovom múzeu bola presťahovaná do budovy MNV. Jej činnosť v tom čase stagnovala. Dôstojné umiestnenie našla Okresná ľudová knižnica v renovovaných priestoroch Osvetového domu kultúry. Správkyňou knižnice sa stala Brigita Smešná, pod vedením ktorej knižnica organizovala bohatú kultúrno-osvetovú prácu (prednášky, hudobné programy a iné podujatia). K 1. januáru 1956 mala knižnica 5 407 zväzkov kníh.

V roku 1956 sa v knižnici konalo viac prednášok, spomienkových večerov v spolupráci s Domom osvety aj literárnych večerov (venovaných Hviezdoslavovi, Štúrovi, Puškinovi, Jégému a ďalším). Veľkou akciou bola návšteva zahraničných spisovateľov z 13 štátov. Delegáciu viedol Vladimír Mináč a Ctibor Štítnický.

V priebehu roka 1956 sa pri Okresnej ľudovej knižnici vytvoril literárny krúžok.

Knižnica okrem iných akcií organizovala Posiedky pri kozúbku. Boli to večery čítania rozprávok a príbehov ľudovými rozprávačmi. Každú nedeľu odpoludnia sa čítali rozprávky. V knižnici sa konávali recitačné preteky organizované v rámci ľudovej umeleckej tvorivosti a tiež pri príležitosti Hviezdoslavovho Kubína. V roku 1957 knižnicu navštívila a deťom čítala rozprávky „teta“ Viera Bálintová.

 
                    </p>
        
                </div>
                <img id="obrObce" src="./static/obec.jpg">
            </div>
            <div class="blok">
                <img id="obrOObci" src="./static/obec1.jpg">
                <div>
                    <h2>Služby pre používateľov :</h2>
                    <p>
                        <ul class="zoznam">
                            <li>absenčné výpožičky kníh, časopisov a jazykových kaziet</li>
                            <li>prezenčné výpožičky periodík, zákonov a literatúry z príručnej knižnice</li>
                            <li>bibliograficko-informačné služby</li>
                            <li>poskytovanie informácií z elektronických databáz</li>
                            <li>poskytovanie faktografických informácií</li>
                            <li>poradenstvo pri vyhľadávaní literatúry vo fonde a v on-line katalógu</li>
                            <li>rezervovanie dokumentov vyhľadaných v on-line katalógu</li>
                            <li>vypracovanie rešerší (tematických súpisov literatúry) – formulár REŠERŠ</li>
                            <li>medziknižničná výpožičná služba (vypožičanie publikácií alebo dodanie kópie článkov z periodík, ktoré knižnica nemá vo svojom fonde z iných knižníc SR) – formulár MVS</li>
                            <li>reprografické služby (vyhotovovanie xerokópií dokumentov z fondu knižnice)</li>
                            <li>prístup na internet, skenovanie, tlač dokumentov</li>
                            <li>informačná výchova a exkurzie</li>
                        </ul>
                    </p>

                </div>
            </div>
            
        </div>

        <footer>
            <div class="narrow">
                <h2>PREZENTÁCIA WEBOVEJ STRÁNKY</h2>
                <p>
                    Táto stránka bola vytvorená na základe získaných znalostí z predmetu Webový dizajn 2. <br>
                    Autorka: Jana Bernaťáková
                </p>
            </div>
        </footer>
    </body>
</html>